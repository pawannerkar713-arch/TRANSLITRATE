# Developer Portfolio — Code & AI

A responsive React + Vite portfolio template with a dark premium aesthetic, violet/cyan accents, animated hero, skills, example project cards, education timeline, and email-based contact.

## Requirements

- Node.js 20 or newer
- npm
- Git (optional, for publishing)

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

## Customize

Edit `src/siteConfig.js` to update:
- Name/brand, headline, bio, roles, and email
- Skills and technology tags
- Project descriptions and repository/demo URLs
- Education
- GitHub and LinkedIn profile URLs

The sample project cards are clearly marked as examples. Replace them with real projects before publishing. Keep skills and credentials accurate.

### Resume

Put your PDF at `public/resume.pdf`, then set `resumeUrl` in `src/siteConfig.js` to:

```js
resumeUrl: `${import.meta.env.BASE_URL}resume.pdf`,
```

## Publish to GitHub Pages

1. Create a GitHub repository, for example `portfolio`.
2. From this project folder, run:

   ```bash
   git init
   git add .
   git commit -m "Create portfolio website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/portfolio.git
   git push -u origin main
   ```

3. On GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **GitHub Actions** as the source.
5. Open the repository's **Actions** tab and wait for `Deploy portfolio to GitHub Pages` to finish.
6. Your site will be published at `https://YOUR-USERNAME.github.io/portfolio/`.

The workflow sets the Vite base path from the repository name automatically. If the repository is named `YOUR-USERNAME.github.io`, Vite's base path should instead be `/`; update `vite.config.js` accordingly for that special user-site repository.

## Notes

- The contact action opens the visitor's email application; no server or contact-form backend is included.
- Social and project URLs are placeholders. Replace them before publishing.
- No actual GitHub push is performed by this template. You must connect your own GitHub account and push the project.
