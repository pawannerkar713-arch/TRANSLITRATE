import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, BrainCircuit, Code2, Cpu,
  Github, Linkedin, Mail, Menu, X, Sparkles, Terminal, Layers3, ExternalLink,
  GraduationCap, Send, ChevronUp, Command, Braces, Palette, Bot
} from 'lucide-react'
import { siteConfig } from './siteConfig'
import './styles.css'

const iconMap = { Code2, BrainCircuit, Cpu, Terminal, Layers3, Braces, Palette, Bot }

function Icon({ name, size = 18, ...props }) {
  const Component = iconMap[name] || Sparkles
  return <Component size={size} strokeWidth={1.7} {...props} />
}

function Header() {
  const [open, setOpen] = useState(false)
  const links = [['About', '#about'], ['Skills', '#skills'], ['Projects', '#projects'], ['Education', '#education'], ['Contact', '#contact']]
  return (
    <header className="header">
      <a className="brand" href="#home" aria-label="Go to homepage">
        <span className="brand-mark"><Command size={18} /></span>
        <span>{siteConfig.brand}<b>.</b></span>
      </a>
      <button className="mobile-toggle" onClick={() => setOpen(!open)} aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open}>
        {open ? <X /> : <Menu />}
      </button>
      <nav className={open ? 'nav nav-open' : 'nav'} aria-label="Main navigation">
        {links.map(([label, href]) => <a key={label} href={href} onClick={() => setOpen(false)}>{label}</a>)}
        <a className="nav-cta" href="#contact" onClick={() => setOpen(false)}>Let's talk <ArrowUpRight size={14} /></a>
      </nav>
    </header>
  )
}

function SectionHeading({ eyebrow, title, description }) {
  return <div className="section-heading reveal">
    <span className="eyebrow"><span className="eyebrow-dot" />{eyebrow}</span>
    <h2>{title}</h2>
    {description && <p>{description}</p>}
  </div>
}

function Hero() {
  const [roleIndex, setRoleIndex] = useState(0)
  const roles = siteConfig.roles
  useEffect(() => {
    const timer = window.setInterval(() => setRoleIndex(i => (i + 1) % roles.length), 2600)
    return () => window.clearInterval(timer)
  }, [roles.length])
  return <section className="hero section-wrap" id="home">
    <div className="hero-copy">
      <div className="availability"><span className="status-pulse" /> OPEN TO LEARNING & COLLABORATION</div>
      <h1>{siteConfig.heroTitle}<br /><span className="gradient-text">{siteConfig.heroAccent}</span></h1>
      <div className="role-line"><span className="role-prefix">I explore</span> <span className="role-rotator" key={roles[roleIndex]}>{roles[roleIndex]}</span><span className="cursor">_</span></div>
      <p className="hero-description">{siteConfig.intro}</p>
      <div className="hero-actions">
        <a className="button button-primary" href="#projects">Explore my work <ArrowRight size={17} /></a>
        <a className="button button-ghost" href={siteConfig.resumeUrl} download={siteConfig.resumeUrl ? undefined : false} onClick={e => { if (!siteConfig.resumeUrl) { e.preventDefault(); document.getElementById('contact').scrollIntoView({ behavior: 'smooth' }) } }}>
          {siteConfig.resumeUrl ? 'Download résumé' : 'Get in touch'} <ArrowDownRight size={17} />
        </a>
      </div>
      <div className="hero-meta">
        <span><span className="meta-line" /> Based in India</span>
        <span className="mono">CSE / AI & ML</span>
      </div>
    </div>
    <div className="hero-visual" aria-label="Decorative AI network illustration">
      <div className="visual-glow" />
      <div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" />
      <div className="visual-grid" />
      <div className="floating-chip chip-top"><BrainCircuit size={16} /><span>AI / ML</span></div>
      <div className="floating-chip chip-bottom"><Code2 size={16} /><span>BUILD · LEARN · REPEAT</span></div>
      <div className="core-card">
        <div className="core-top"><span className="core-dot" /><span className="core-dot" /><span className="core-dot" /><span className="core-label">SYSTEM / 001</span></div>
        <div className="core-symbol"><Braces size={72} strokeWidth={1.1} /></div>
        <div className="core-name">{siteConfig.shortName}</div>
        <div className="core-caption">Curiosity → Code → Creation</div>
        <div className="core-progress"><span /></div>
      </div>
      <div className="visual-index index-left">FIG. 01 <span>— DIGITAL THINKING</span></div>
      <div className="visual-index index-right">AI × CODE</div>
    </div>
    <a className="scroll-cue" href="#about"><span className="scroll-wheel" /> SCROLL TO EXPLORE</a>
  </section>
}

function About() {
  const highlights = [
    { icon: 'BrainCircuit', title: 'AI curious', text: 'Exploring machine learning concepts and practical applications.' },
    { icon: 'Code2', title: 'Build by doing', text: 'Learning core programming through small, hands-on projects.' },
    { icon: 'Layers3', title: 'Always improving', text: 'Turning new concepts into useful, thoughtful experiences.' },
  ]
  return <section className="section-wrap section-block" id="about">
    <SectionHeading eyebrow="A LITTLE ABOUT ME" title={<>Curious mind.<br /><span className="muted-heading">Builder mindset.</span></>} description="I’m a student at the intersection of software, design, and intelligent systems." />
    <div className="about-layout">
      <div className="about-text reveal">
        <p className="large-copy">{siteConfig.about}</p>
        <p className="body-copy">I believe the best way to learn technology is to make things with it. My focus is on building strong fundamentals, experimenting with ideas, and documenting what I learn along the way.</p>
        <a className="text-link" href="#contact">More about my journey <ArrowUpRight size={16} /></a>
      </div>
      <div className="highlight-list">
        {highlights.map((item, i) => <article className="highlight-card reveal" style={{ '--delay': `${i * 100}ms` }} key={item.title}>
          <div className="highlight-icon"><Icon name={item.icon} size={21} /></div>
          <div><h3>{item.title}</h3><p>{item.text}</p></div>
          <span className="highlight-number">0{i + 1}</span>
        </article>)}
      </div>
    </div>
  </section>
}

function Skills() {
  return <section className="section-wrap section-block" id="skills">
    <SectionHeading eyebrow="THE TOOLKIT" title={<>Skills I’m building<span className="accent-dot">.</span></>} description="A living toolkit. This section is intentionally editable—keep only the technologies you can confidently discuss." />
    <div className="skills-grid">
      {siteConfig.skills.map((group, i) => <article className="skill-card reveal" style={{ '--delay': `${i * 70}ms` }} key={group.title}>
        <div className="skill-card-top"><div className="skill-icon"><Icon name={group.icon} size={21} /></div><span className="mono">0{i + 1}</span></div>
        <h3>{group.title}</h3><p>{group.description}</p>
        <div className="skill-tags">{group.items.map(skill => <span key={skill}>{skill}</span>)}</div>
      </article>)}
    </div>
  </section>
}

function Projects() {
  return <section className="section-wrap section-block" id="projects">
    <SectionHeading eyebrow="SELECTED WORK" title={<>Ideas into <span className="gradient-text">experiments.</span></>} description="A few starting points for the projects section. Replace these clearly marked examples with your real work before publishing." />
    <div className="projects-grid">
      {siteConfig.projects.map((project, i) => <article className={`project-card project-${i + 1} reveal`} style={{ '--delay': `${i * 100}ms` }} key={project.title}>
        <div className="project-art">
          <div className="art-noise" />
          <div className="art-orb orb-a" /><div className="art-orb orb-b" />
          <div className="project-art-icon"><Icon name={project.icon} size={36} /></div>
          <span className="project-index">PROJECT / 0{i + 1}</span>
          <span className="example-label">EXAMPLE — REPLACE</span>
        </div>
        <div className="project-content">
          <div className="project-title-row"><h3>{project.title}</h3><ArrowUpRight size={18} /></div>
          <p>{project.description}</p>
          <div className="project-tags">{project.stack.map(tag => <span key={tag}>{tag}</span>)}</div>
          <div className="project-links">
            <a href={project.githubUrl} target="_blank" rel="noreferrer" aria-label={`GitHub repository for ${project.title}`}>GitHub <Github size={15} /></a>
            <a href={project.liveUrl} target="_blank" rel="noreferrer" aria-label={`Live demo for ${project.title}`}>Live demo <ExternalLink size={14} /></a>
          </div>
        </div>
      </article>)}
    </div>
  </section>
}

function Education() {
  return <section className="section-wrap section-block" id="education">
    <SectionHeading eyebrow="THE FOUNDATION" title={<>Learning in progress<span className="accent-dot">.</span></>} description="Education, credentials, and milestones—add verified details as your journey grows." />
    <div className="timeline">
      {siteConfig.education.map((item, i) => <article className="timeline-item reveal" key={item.title}>
        <div className="timeline-marker"><GraduationCap size={19} /></div>
        <div className="timeline-date mono">{item.period}</div>
        <div className="timeline-content"><h3>{item.title}</h3><p className="timeline-place">{item.institution}</p><p>{item.description}</p></div>
        <span className="timeline-index">0{i + 1}</span>
      </article>)}
    </div>
    <div className="cert-note reveal"><Sparkles size={18} /><p><strong>Certifications & achievements</strong><br />Add only courses, certificates, internships, or hackathon results you have actually completed. No credentials are pre-filled here.</p></div>
  </section>
}

function Contact() {
  const mail = `mailto:${siteConfig.email}?subject=${encodeURIComponent('Hello from your portfolio')}`
  return <section className="section-wrap section-block contact-section" id="contact">
    <div className="contact-panel reveal">
      <div className="contact-spark"><Sparkles size={20} /></div>
      <span className="eyebrow"><span className="eyebrow-dot" /> NEXT UP</span>
      <h2>Have an idea?<br /><span className="gradient-text">Let’s make it real.</span></h2>
      <p>I’m always interested in learning, collaborating, and building something useful. Send a message and say hello.</p>
      <a className="button button-primary" href={mail}><Mail size={17} /> Say hello <ArrowUpRight size={16} /></a>
      <div className="contact-orbit orbit-contact-one" /><div className="contact-orbit orbit-contact-two" />
    </div>
    <div className="contact-bottom">
      <div><span className="mono">EMAIL</span><a href={mail}>{siteConfig.email}</a></div>
      <div className="social-links">
        <a href={siteConfig.githubUrl} target="_blank" rel="noreferrer" aria-label="GitHub profile"><Github size={18} /></a>
        <a href={siteConfig.linkedinUrl} target="_blank" rel="noreferrer" aria-label="LinkedIn profile"><Linkedin size={18} /></a>
      </div>
    </div>
  </section>
}

function Footer() {
  return <footer className="footer section-wrap">
    <a className="brand" href="#home"><span className="brand-mark"><Command size={16} /></span><span>{siteConfig.brand}<b>.</b></span></a>
    <span className="footer-note">Designed with curiosity. Built with code.</span>
    <a className="back-top" href="#home">BACK TO TOP <ChevronUp size={15} /></a>
  </footer>
}

function App() {
  useEffect(() => {
    const nodes = document.querySelectorAll('.reveal')
    if (!('IntersectionObserver' in window)) {
      nodes.forEach(node => node.classList.add('is-visible'))
      return
    }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible')
          observer.unobserve(entry.target)
        }
      })
    }, { threshold: 0.12 })
    nodes.forEach(node => observer.observe(node))
    return () => observer.disconnect()
  }, [])
  return <><div className="ambient ambient-one" /><div className="ambient ambient-two" /><Header /><main><Hero /><About /><Skills /><Projects /><Education /><Contact /></main><Footer /></>
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>)
