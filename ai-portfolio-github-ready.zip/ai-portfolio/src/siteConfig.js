// Edit this file to personalize your portfolio.
// Keep skills and credentials accurate. Project links below are placeholders.
export const siteConfig = {
  brand: 'pawan.dev',
  shortName: 'PN',
  fullName: 'Your Name',
  heroTitle: 'Building the future',
  heroAccent: 'with code & AI.',
  roles: ['software experiences', 'AI / ML experiments', 'useful web apps', 'ideas into prototypes'],
  intro: 'I’m a Computer Science student exploring software development and Artificial Intelligence. I enjoy learning by building, solving problems, and turning ideas into practical projects.',
  about: 'I’m a CSE student with a growing interest in Artificial Intelligence and Machine Learning. I’m focused on strengthening my programming fundamentals while exploring how thoughtful software can solve real problems.',
  email: 'hello@example.com',
  githubUrl: 'https://github.com/your-username',
  linkedinUrl: 'https://www.linkedin.com/in/your-username/',
  // Add a PDF at public/resume.pdf and set this to `${import.meta.env.BASE_URL}resume.pdf`.
  resumeUrl: '',
  skills: [
    { title: 'Programming', icon: 'Code2', description: 'Core languages and problem-solving fundamentals.', items: ['Python (learning)', 'C++ (learning)', 'JavaScript basics'] },
    { title: 'Web development', icon: 'Braces', description: 'Creating responsive interfaces for the web.', items: ['HTML', 'CSS', 'JavaScript', 'React (learning)'] },
    { title: 'AI & machine learning', icon: 'BrainCircuit', description: 'Exploring intelligent systems and data-driven ideas.', items: ['AI fundamentals', 'ML concepts', 'Data exploration'] },
    { title: 'Tools & workflow', icon: 'Terminal', description: 'Tools for building, debugging, and sharing projects.', items: ['VS Code', 'Git', 'GitHub', 'Command line'] },
    { title: 'Design thinking', icon: 'Palette', description: 'Making digital experiences clear and approachable.', items: ['UI fundamentals', 'Responsive design', 'Prototyping'] },
    { title: 'Future explorations', icon: 'Cpu', description: 'Topics to explore as skills and projects grow.', items: ['Computer vision', 'APIs', 'Deployment'] }
  ],
  projects: [
    {
      title: 'FitFuel Planner',
      description: 'Example project: a responsive fitness dashboard with workout routines, Indian meal ideas, and simple habit tracking.',
      stack: ['HTML', 'CSS', 'JavaScript'],
      icon: 'Cpu',
      githubUrl: 'https://github.com/your-username/fitfuel-planner',
      liveUrl: 'https://your-username.github.io/fitfuel-planner/'
    },
    {
      title: 'Smart Study Companion',
      description: 'Example concept: a student-focused learning dashboard for organizing topics, study sessions, and revision goals.',
      stack: ['React', 'CSS', 'UI Design'],
      icon: 'Layers3',
      githubUrl: 'https://github.com/your-username/smart-study-companion',
      liveUrl: 'https://your-username.github.io/smart-study-companion/'
    },
    {
      title: 'AI Idea Lab',
      description: 'Example concept: a small collection of experiments exploring AI workflows and practical problem-solving.',
      stack: ['Python', 'AI Concepts', 'Prototyping'],
      icon: 'BrainCircuit',
      githubUrl: 'https://github.com/your-username/ai-idea-lab',
      liveUrl: 'https://your-username.github.io/ai-idea-lab/'
    }
  ],
  education: [
    {
      period: '2025 — EXPECTED 2029',
      title: 'B.Tech — Computer Science & Engineering (AI/ML)',
      institution: 'Your college or university',
      description: 'Update this entry with your official program, institution, and expected graduation year.'
    },
    {
      period: 'FOUNDATIONS',
      title: 'Learning through projects',
      institution: 'Self-directed learning',
      description: 'Building programming fundamentals and exploring web development, AI concepts, and version control.'
    }
  ]
}
